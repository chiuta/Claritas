#!/bin/bash
# Rulează pe macOS cu Xcode instalat (nu doar Command Line Tools).
set -e
cd "$(dirname "$0")"
xcrun safari-web-extension-converter ./extension \
  --project-location ./xcode --app-name Claritas \
  --bundle-identifier tf.trom.claritas --copy-resources --force
echo "Proiect creat în ./xcode. Deschide-l în Xcode, alege schema 'Claritas (macOS)' sau '(iOS)', apasă Run."
echo "Apoi: Safari > Setări > Extensii > Claritas (bifează) și acordă accesul la site-uri."
echo "Dacă nu apare: Safari > Dezvoltare > Permite extensii nesemnate (la fiecare pornire Safari)."
